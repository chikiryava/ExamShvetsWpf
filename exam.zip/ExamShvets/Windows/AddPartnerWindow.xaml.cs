﻿using ExamShvets.Models;
using System;
using System.Linq;
using System.Windows;

namespace ExamShvets.Windows
{
    public partial class AddPartnerWindow : Window
    {
        private readonly ExamShvetsContext _context = new();
        private PartnerDTO _partnerDTO;

        public AddPartnerWindow()
        {
            InitializeComponent();
            LoadTypes();
        }
        public AddPartnerWindow(PartnerDTO partnerDTO)
        {
            InitializeComponent();
            LoadTypes();
            FillFields(partnerDTO);
            add.Content = "Изменить";
            _partnerDTO = partnerDTO;
        }

        private void FillFields(PartnerDTO partnerDTO)
        {
            name.Text = partnerDTO.Name;
            rating.Text = partnerDTO.Rating.ToString();
            adress.Text = partnerDTO.Address;
            directorName.Text = partnerDTO.Position;
            phoneNumber.Text = partnerDTO.Phone;
            email.Text = partnerDTO.Email;
            var allTypes = type.ItemsSource as List<PartnerTypeImport>;
            type.SelectedItem = allTypes.Where(t => t.Title == partnerDTO.Type).FirstOrDefault();

        }

        private void LoadTypes()
        {
            // Загружаем список типов партнёров
            type.ItemsSource = _context.PartnerTypeImports.ToList();
        }

        private void AddPartner(object sender, RoutedEventArgs e)
        {
            // Простейшая валидация: убедимся, что выбрали тип и ввели обязательные поля
            if (type.SelectedItem is not PartnerTypeImport selectedType)
            {
                MessageBox.Show("Пожалуйста, выберите тип партнёра.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(name.Text) ||
                !int.TryParse(rating.Text, out int parsedRating) ||
                parsedRating<0 ||
                string.IsNullOrWhiteSpace(adress.Text) ||
                string.IsNullOrWhiteSpace(directorName.Text) ||
                string.IsNullOrWhiteSpace(phoneNumber.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля и проверьте формат рейтинга.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Создаём новую сущность партнёра
                var newPartner = new PartnersImport
                {

                    Title = name.Text.Trim(),
                    PartnerTypeId = selectedType.PartnerTypeId,
                    Rating = parsedRating,
                    AddressPartner = adress.Text.Trim(),
                    Director = directorName.Text.Trim(),
                    PhonePartner = phoneNumber.Text.Trim(),
                    EmailPartner = string.IsNullOrWhiteSpace(email.Text) ? null : email.Text.Trim()
                };
                if (_partnerDTO != null)
                {

               
                    var partner = _context.PartnersImports.Where(p => p.PartnerId == _partnerDTO.Id).FirstOrDefault();
                    if(partner != null)
                    {
                        partner.PartnerId = _partnerDTO.Id;
                        partner.AddressPartner = adress.Text.Trim();
                        partner.Director = directorName.Text;
                        partner.PhonePartner = phoneNumber.Text;
                        partner.Title = name.Text.Trim();
                        partner.PartnerTypeId = selectedType.PartnerTypeId;
                        partner.EmailPartner = email.Text.Trim();
                        _context.PartnersImports.Update(partner);
                        _context.SaveChanges();

                        MessageBox.Show("Партнёр успешно обновлен.", "Готово", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    newPartner.PartnerId = _context.PartnersImports.Count() + 2;
                    _context.PartnersImports.Add(newPartner);
                    _context.SaveChanges();
                    MessageBox.Show("Партнёр успешно обновлен.", "Готово", MessageBoxButton.OK, MessageBoxImage.Information);

                }





                // Закрываем окно
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
